const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const db = new sqlite3.Database(path.join(__dirname, 'xau.db'));

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS price_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      price REAL NOT NULL,
      source TEXT,
      fetched_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS econ_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      time TEXT,
      country TEXT NOT NULL,
      event TEXT NOT NULL,
      impact TEXT
    )
  `);
  db.get('SELECT COUNT(*) AS c FROM econ_events', [], (err, row) => {
    if (!err && row.c === 0) {
      const seed = [
        ['2026-10-01', '20:30', 'US', 'Initial Jobless Claims', 'medium'],
        ['2026-10-02', '20:30', 'US', 'Non-Farm Payrolls (NFP)', 'high'],
        ['2026-10-02', '20:30', 'US', 'Unemployment Rate', 'high'],
        ['2026-10-06', '21:00', 'US', 'ISM Services PMI', 'medium'],
        ['2026-10-08', '03:00', 'US', 'FOMC Meeting Minutes', 'high'],
        ['2026-10-13', '20:30', 'US', 'CPI y/y', 'high'],
        ['2026-10-15', '20:30', 'US', 'Retail Sales', 'medium'],
        ['2026-10-20', '20:30', 'US', 'PPI y/y', 'medium'],
      ];
      const stmt = db.prepare('INSERT INTO econ_events (date, time, country, event, impact) VALUES (?, ?, ?, ?, ?)');
      seed.forEach(e => stmt.run(e));
      stmt.finalize(() => console.log('📅 Kalender ekonomi dummy dimasukkan.'));
    }
  });
});

module.exports = db;
