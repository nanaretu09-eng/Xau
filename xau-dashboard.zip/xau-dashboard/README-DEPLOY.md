# XAU Dashboard — Panduan Deploy ke Railway

## Persiapan
1. Buat akun di https://railway.app (bisa login via GitHub)
2. Install Git di komputer (https://git-scm.com)

## Cara Deploy
1. Buat repositori baru di GitHub (mis. `xau-dashboard`), lalu upload semua file project ini
2. Di Railway: New Project → Deploy from GitHub repo → pilih repo tadi
3. Railway otomatis mendeteksi Node.js dan menjalankan `npm start`
4. Setelah build selesai: tab Settings → Networking → Generate Domain
5. Dashboard online di domain tersebut, contoh: `https://xau-dashboard.up.railway.app`

## Catatan penting
- Database SQLite (`xau.db`) tersimpan di filesystem container. Setiap redeploy meresetnya.
  (Normal untuk pemakaian pribadi; riwayat tren terkumpul lagi otomatis.)
- Railway free trial memberi kredit terbatas. Setelah habis, pakai hemat:
  service bisa di-sleep saat tidak dipakai.
- Variabel `PORT` diset otomatis oleh Railway — kode sudah mendukungnya.

## Jalankan lokal
```
npm install
npm start      # buka http://localhost:3001
```
