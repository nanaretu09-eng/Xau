const express = require('express');
const path = require('path');
const fetch = require('node-fetch');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

async function fetchGoldPrice() {
  const sources = [
    { name: 'gold-api.com', url: 'https://api.gold-api.com/price/XAU',
      parse: (j) => j && j.price ? { price: j.price } : null },
    { name: 'PAXG (proxy emas)', url: 'https://api.coingecko.com/api/v3/simple/price?ids=pax-gold&vs_currencies=usd',
      parse: (j) => j && j['pax-gold'] && j['pax-gold'].usd ? { price: j['pax-gold'].usd, note: 'PAXG (proxy emas)' } : null },
  ];
  for (const s of sources) {
    try {
      const res = await fetch(s.url, { timeout: 8000 });
      if (!res.ok) continue;
      const parsed = s.parse(await res.json());
      if (parsed && parsed.price > 100) return { ...parsed, source: s.name };
    } catch (e) { /* sumber berikutnya */ }
  }
  return null;
}

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (e, r) => e ? reject(e) : resolve(r)));
}
function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (e, r) => e ? reject(e) : resolve(r)));
}
function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function (e) { e ? reject(e) : resolve(this); }));
}

app.get('/api/price', async (req, res) => {
  try {
    const data = await fetchGoldPrice();
    if (!data) {
      const last = await dbGet('SELECT price, fetched_at FROM price_history ORDER BY id DESC LIMIT 1');
      if (!last) return res.status(502).json({ error: 'Tidak bisa mengambil harga dari semua sumber' });
      return res.json({ price: last.price, source: 'cache (riwayat terakhir)', fetched_at: last.fetched_at, stale: true });
    }
    await dbRun('INSERT INTO price_history (price, source) VALUES (?, ?)', [data.price, data.source]);
    res.json({ price: data.price, source: data.source, note: data.note || null, fetched_at: new Date().toISOString(), stale: false });
  } catch (e) {
    res.status(500).json({ error: 'Gagal mengambil harga' });
  }
});

app.get('/api/history', async (req, res) => {
  try {
    const rows = await dbAll('SELECT price, fetched_at FROM price_history ORDER BY id DESC LIMIT 100');
    res.json(rows.reverse());
  } catch { res.status(500).json({ error: 'Gagal mengambil riwayat' }); }
});

app.get('/api/events', async (req, res) => {
  try { res.json(await dbAll('SELECT * FROM econ_events ORDER BY date ASC LIMIT 15')); }
  catch { res.status(500).json({ error: 'Gagal mengambil kalender' }); }
});

app.get('/api/levels', async (req, res) => {
  try {
    const rows = await dbAll('SELECT price FROM price_history ORDER BY id DESC LIMIT 100');
    if (!rows.length) return res.json({ support: null, resistance: null, note: 'Data belum cukup — terkumpul otomatis seiring dashboard diakses.' });
    const prices = rows.map(r => r.price);
    const current = prices[0];
    const below = prices.filter(p => p < current);
    const above = prices.filter(p => p > current);
    res.json({ support: below.length ? Math.max(...below) : null, resistance: above.length ? Math.min(...above) : null,
               min: Math.min(...prices), max: Math.max(...prices), samples: prices.length });
  } catch { res.status(500).json({ error: 'Gagal menghitung level' }); }
});

app.get('/{*splat}', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => console.log(`XAU Dashboard berjalan di port ${PORT}`));
